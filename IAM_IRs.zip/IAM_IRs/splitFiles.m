Fs = 44100;
values = [0, 15, 25, 45, 54, 75, 90, -15, -25, -45, -54, -75, -81];
for k = 1 : 13
    for n = 1 : 360
        filename = sprintf('azi_%d_0_ele_%d_0.wav', (n-1), values(k));
        leftChannelName = sprintf('azi_%d_0_ele_%d_0_L.wav', (n-1), values(k));
        rightChannelName = sprintf('azi_%d_0_ele_%d_0_R.wav', (n-1), values(k));
        currentFile = audioread(filename);
        leftChannel = currentFile(:,1);
        rightChannel = currentFile(:,2);
        audiowrite(leftChannelName,leftChannel,Fs);
        audiowrite(rightChannelName,rightChannel,Fs);
    end
    
end

    