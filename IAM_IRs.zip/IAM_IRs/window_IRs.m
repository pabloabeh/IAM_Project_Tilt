%window IRs
Fs = 44100;
values = [0, 15, 25, 45, 54, 75, 90, -15, -25, -45, -54, -75, -81];

for k = 1 : 13
    for n = 1 : 360
        filename_L = sprintf('azi_%d_0_ele_%d_0_L.wav', (n-1), values(k));
        filename_R = sprintf('azi_%d_0_ele_%d_0_R.wav', (n-1), values(k));
        leftChannelName = sprintf('azi_%d_0_ele_%d_0_L_windowed.wav', (n-1), values(k));
        rightChannelName = sprintf('azi_%d_0_ele_%d_0_R_windowed.wav', (n-1), values(k));
        currentFile_L = audioread(filename_L);
        currentFile_R = audioread(filename_R);
        w = hann(length(currentFile_L),'periodic');
        leftChannel_windowed = currentFile_L .* w;
        rightChannel_windowed = currentFile_R .* w;
        audiowrite(leftChannelName,leftChannel_windowed,Fs);
        audiowrite(rightChannelName,rightChannel_windowed,Fs);
    end
    
end
